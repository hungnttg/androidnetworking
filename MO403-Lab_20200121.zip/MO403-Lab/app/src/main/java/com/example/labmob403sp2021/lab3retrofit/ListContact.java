package com.example.labmob403sp2021.lab3retrofit;

public class ListContact {
    private Contact[] contact;//bien nay phai trung voi object trong API
    public Contact[] getContact(){
        return contact;//bien nay phai trung voi object trong API
    }
}
