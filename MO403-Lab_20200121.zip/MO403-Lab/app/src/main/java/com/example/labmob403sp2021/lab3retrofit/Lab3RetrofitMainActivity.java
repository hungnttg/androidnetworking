package com.example.labmob403sp2021.lab3retrofit;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.TextView;

import com.example.labmob403sp2021.R;

public class Lab3RetrofitMainActivity extends AppCompatActivity {
    TextView textView;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_lab3_retrofit_main);
        textView = findViewById(R.id.lab3RetroTextview);
        LoadData loadData = new LoadData();
        loadData.loadJSON(textView);
       // textView.setText(loadData.jSONStr.toString());
    }
}