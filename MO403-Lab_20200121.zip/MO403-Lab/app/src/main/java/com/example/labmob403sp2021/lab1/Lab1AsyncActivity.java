package com.example.labmob403sp2021.lab1;

import androidx.appcompat.app.AppCompatActivity;

import android.graphics.Bitmap;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

import com.example.labmob403sp2021.R;

public class Lab1AsyncActivity extends AppCompatActivity
        implements View.OnClickListener,Bai3Interface {
    TextView textView;
    Button button;
    ImageView imageView;
    public static final String StrImg = "http://sohanews.sohacdn.com/2016/photo-2-1465288075049.jpg";
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_lab1_async);
        textView = findViewById(R.id.lab1TextView);
        button = findViewById(R.id.lab1btnLoad);
        imageView = findViewById(R.id.lab1img);
        button.setOnClickListener(this);
    }

    @Override
    public void onClick(View v) {
        switch (v.getId())
        {
            case R.id.lab1btnLoad:
                new Bai3Async(this,this).execute((StrImg));//download data from server
                break;
        }

    }

    @Override
    public void onImageLoaded(Bitmap bitmap) {
        imageView.setImageBitmap(bitmap);
        textView.setText("Complete");
    }

    @Override
    public void onError() {
        textView.setText("Error when downloading");
    }
}