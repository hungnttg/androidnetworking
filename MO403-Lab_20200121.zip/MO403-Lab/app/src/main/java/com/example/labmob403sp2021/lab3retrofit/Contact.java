package com.example.labmob403sp2021.lab3retrofit;

public class Contact {
    private String name;
    private String email;

    public String getName() {
        return name;
    }

    public String getEmail() {
        return email;
    }

}
