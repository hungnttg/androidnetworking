package com.example.labmob403sp2021.lab3retrofit;

import android.util.Log;
import android.widget.TextView;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;
import retrofit2.Retrofit;
import retrofit2.converter.gson.GsonConverterFactory;

public class LoadData {
    private List<Contact> data;
    String jSONStr=null;
    public List<Contact> loadJSON(TextView textView){
        //get link
        Retrofit retrofit = new Retrofit.Builder()
                .baseUrl("https://batdongsanabc.000webhostapp.com/mob403lab3/")
                .addConverterFactory(GsonConverterFactory.create())
                .build();
        //create request
        RequestRe requestRe = retrofit.create(RequestRe.class);
        //call
        Call<ListContact> call = requestRe.getJSON();
        //put to queue
        call.enqueue(new Callback<ListContact>() {
            //if success
            @Override
            public void onResponse(Call<ListContact> call, Response<ListContact> response) {
                ListContact jsonResponse = response.body();//get data
                data = new ArrayList<>(Arrays.asList(jsonResponse.getContact()));//convert to list
                for(Contact c: data)
                {
                    jSONStr += "Name: "+c.getName()+"\n\n";
                    jSONStr += "Email: "+c.getEmail()+"\n\n";
                }
                //adapter = new Adapter(data)
                //recyclerview.setAdapter(adapter);
                textView.setText(jSONStr);
            }

            @Override
            public void onFailure(Call<ListContact> call, Throwable t) {
                Log.d("Error",t.getMessage());
                textView.setText(t.getMessage());
            }
        });

        return data;
    }
}
