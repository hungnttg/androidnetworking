package com.example.labmob403sp2021.lab1;

import android.graphics.Bitmap;

public interface Bai3Interface {
    void onImageLoaded(Bitmap bitmap);
    void onError();
}
