package com.example.labmob403sp2021.lab2;

import androidx.appcompat.app.AppCompatActivity;

import android.os.AsyncTask;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import com.example.labmob403sp2021.R;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.MalformedURLException;
import java.net.URL;

public class B1Lab2GetMainActivity extends AppCompatActivity {
    public static final String duongdan = "http://10.22.216.24/0/student_get.php";
    TextView textView;
    EditText txtUser, txtScore;
    Button button;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_b1_lab2_get_main);
        textView = findViewById(R.id.lab2b1textview);
        button = findViewById(R.id.lab2b1btn);
        txtUser = findViewById(R.id.lab2b1User);
        txtScore = findViewById(R.id.lab2b1Score);

    }

    public void lab21Asyn(View view) {
        B1Lab2Asyn a = new B1Lab2Asyn(txtUser.getText().toString(),txtScore.getText().toString());
        a.execute();//call API
    }

    public class B1Lab2Asyn extends AsyncTask<Void,Void,Void>{
        String path = B1Lab2GetMainActivity.duongdan;
        private String result;
        private String name;
        private String score;
        public B1Lab2Asyn(String name, String score) {
            this.path = path;
            this.name = name;
            this.score = score;
        }
        //1.connect to server
        //2.get data from server
        @Override
        protected Void doInBackground(Void... voids) {
            path += "?name="+this.name+"&score="+this.score;
            try {
                URL url = new URL(path);//get path
                BufferedReader br = new BufferedReader(
                        new InputStreamReader(url.openConnection().getInputStream())
                );//connect to server
                String line="";
                StringBuilder sb = new StringBuilder();
                while ((line=br.readLine())!=null)
                {
                    sb.append(line);
                }
                result = sb.toString();
            } catch (MalformedURLException e) {
                e.printStackTrace();
            } catch (IOException e) {
                e.printStackTrace();
            }
            return null;
        }
        //post data to client
        @Override
        protected void onPostExecute(Void aVoid) {
            super.onPostExecute(aVoid);
            textView.setText(result);
        }
    }
}