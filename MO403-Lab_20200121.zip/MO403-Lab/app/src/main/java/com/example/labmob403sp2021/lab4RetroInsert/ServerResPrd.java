package com.example.labmob403sp2021.lab4RetroInsert;

public class ServerResPrd {
    private Prd products;
    private String result;
    private String message;

    public Prd getProducts() {//tra ve object
        return products;
    }

    public String getResult() {//tra ve ket qua
        return result;
    }

    public String getMessage() {//tra ve thong bao loi
        return message;
    }
}
