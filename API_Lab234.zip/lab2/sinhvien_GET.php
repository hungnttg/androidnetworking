<?php
    $name = $_GET['name'];//lay du lieu truong name tu client chuyen len
    $score = $_GET['score'];
    echo "Name: ".$name." - score: ".$score;//in ra thong tin
?>
