package com.example.mob403demo3retro;

public class ServerResPrd { //lop nhan (get) du lieu tra ve tu server
    private Prd products;
    private String result;//khong doi ten
    private String message;//khong doi ten

    public Prd getProducts() {
        return products;
    }

    public String getResult() {
        return result;
    }

    public String getMessage() {
        return message;
    }
}
