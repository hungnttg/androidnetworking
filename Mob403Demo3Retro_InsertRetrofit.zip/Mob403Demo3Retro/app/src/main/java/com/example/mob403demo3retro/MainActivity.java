package com.example.mob403demo3retro;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;
import retrofit2.Retrofit;
import retrofit2.converter.gson.GsonConverterFactory;

public class MainActivity extends AppCompatActivity {
    /*
    * Cách sử dụng:
1. Khai báo thư viện trong gradle
2. xac dinh cau truc API-> Bang co 3 truong: products (name, price, description)
3. Dinh nghia Model cho API: Prd
4. Dinh nghia listProduct (Server tra ve khi ket noi den server), chú ý: nhớ lấy đúng tên bảng và tên trường dữ liệu như trên API
5. Dinh nghia interface giao tiep voi server
6. Goi thu vien retrofit

*/
    //API:
    //https://batdongsanabc.000webhostapp.com/mob403lab5/create_product.php
    Button button;
    TextView textView;
    EditText txtName,txtPrice,txtDes;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        button = findViewById(R.id.l31btnInsert);
        textView = findViewById(R.id.l31tvKQ);
        txtName = findViewById(R.id.l31txtName);
        txtPrice = findViewById(R.id.l31txtPrice);
        txtDes = findViewById(R.id.l31txtDes);
        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                insertData();
            }
        });
    }
    public void insertData()
    {
        //1.khai bao doi tuong chua du lieu
        Prd prd = new Prd();
        //2.nhap du lieu vao doi tuong
        prd.setName(txtName.getText().toString());
        prd.setPrice(txtPrice.getText().toString());
        prd.setDescription(txtDes.getText().toString());
        //3. su dung thu vien retrofit
        Retrofit retrofit
                =new Retrofit.Builder()
                .baseUrl("https://batdongsanabc.000webhostapp.com/mob403lab5/")
                .addConverterFactory(GsonConverterFactory.create())
                .build();
        //4. goi interface
        InterInsertPrd interInsertPrd = retrofit.create(InterInsertPrd.class);
        //5. thuc thi ham trong interface
        Call<ServerResPrd> call =
                interInsertPrd.insertPrd(prd.getName(),prd.getPrice(),prd.getDescription());
        //6. thuc thi phia server
        call.enqueue(new Callback<ServerResPrd>() {
            //tra ve ket qua
            @Override
            public void onResponse(Call<ServerResPrd> call, Response<ServerResPrd> response) {
                ServerResPrd serverResPrd = response.body();//lay ve ket qua
                textView.setText(serverResPrd.getMessage());
            }
            //neu loi
            @Override
            public void onFailure(Call<ServerResPrd> call, Throwable t) {
                textView.setText(t.getMessage());
            }
        });
    }
}
