package com.example.lab3.retrofit;

public class ListContact {
    private Contact[] c;
    public Contact[] getCont()
    {
        return c;
    }
}
