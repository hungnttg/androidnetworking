package com.example.lab3.lab31Asyn;

import android.content.Context;
import android.os.AsyncTask;
import android.widget.ListView;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.ArrayList;

public class Lab31AsyncAsyncTask extends AsyncTask<Void,Void,Void> {
    Lab31AsyncAdapter adapter;
    private ListView listView;
    private Context context;
    ArrayList<Contact> list;
    private String link = "https://batdongsanabc.000webhostapp.com/mob403lab3/index.php";
    private String jsonStr=null;
    public Lab31AsyncAsyncTask(Context context, ListView listView)
    {
        this.context = context;
        this.list = new ArrayList<>();
        this.listView = listView;
    }

    @Override
    protected void onPostExecute(Void aVoid) {
        super.onPostExecute(aVoid);
        adapter = new Lab31AsyncAdapter(context,list);
        listView.setAdapter(adapter);

    }

    @Override
    protected Void doInBackground(Void... voids) {
        try {
            URL url = new URL(link);
            HttpURLConnection urlConnection = (HttpURLConnection)url.openConnection();
            BufferedReader br = new
                    BufferedReader(new InputStreamReader(urlConnection.getInputStream()));
            StringBuffer sb = new StringBuffer();
            String line="";
            while ((line=br.readLine())!=null)
            {
                sb.append(line);
            }
            jsonStr = sb.toString();
            //xu ly json/////////////
            JSONObject contacts = new JSONObject(jsonStr);
            JSONArray jsonArray = contacts.getJSONArray("contacts");
            for(int i=0;i<jsonArray.length();i++)
            {
                JSONObject c = jsonArray.getJSONObject(i);
                String id = c.getString("id");
                String name = c.getString("name");

                JSONObject phone = c.getJSONObject("phone");
                String mobile = phone.getString("mobile");

                Contact contact = new Contact();
                contact.setId(id);
                contact.setName(name);
                contact.setMobile(mobile);
                list.add(contact);
            }
            //ket thuc/////////////////
            urlConnection.disconnect();
        } catch (Exception e) {
            e.printStackTrace();
        }
        return null;
    }
}
