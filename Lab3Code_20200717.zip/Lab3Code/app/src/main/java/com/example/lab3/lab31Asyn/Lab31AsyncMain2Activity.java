package com.example.lab3.lab31Asyn;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.ListView;

import com.example.lab3.R;

public class Lab31AsyncMain2Activity extends AppCompatActivity {
    ListView listView;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_lab31_async_main2);
        listView = findViewById(R.id.listview_labs31async);
        Lab31AsyncAsyncTask async = new Lab31AsyncAsyncTask(this,listView);
        async.execute();
    }
}
