package com.example.lab3.retrofit;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;
import retrofit2.Retrofit;
import retrofit2.converter.gson.GsonConverterFactory;

public class LoadData {
    public List<Contact> data;
    public String jsonStr=null;
    public List<Contact> loadJSON()
    {
        Retrofit retrofit = new Retrofit.Builder()
                .baseUrl("https://batdongsanabc.000webhostapp.com/mob403lab3")
                .addConverterFactory(GsonConverterFactory.create())
                .build();
        RequestRe request = retrofit.create(RequestRe.class);
        Call<ListContact> call = request.getJSON();
        call.enqueue(new Callback<ListContact>() {
            @Override
            public void onResponse(Call<ListContact> call, Response<ListContact> response) {
                ListContact jsonResponse = response.body();
                data = new ArrayList<>(Arrays.asList(jsonResponse.getCont()));

                for(Contact c: data)
                {
                    jsonStr += "Name: "+c.getName()+"\n\n";
                    jsonStr += "Email: "+c.getEmail()+"\n\n";
                    jsonStr += "Mobile: "+c.getMobile()+"\n\n";
                }

            }

            @Override
            public void onFailure(Call<ListContact> call, Throwable t) {

            }
        });
        return data;
    }
    public String loadJSON1()
    {
        Retrofit retrofit = new Retrofit.Builder()
                .baseUrl("https://batdongsanabc.000webhostapp.com/mob403lab3")
                .addConverterFactory(GsonConverterFactory.create())
                .build();
        RequestRe request = retrofit.create(RequestRe.class);
        Call<ListContact> call = request.getJSON();
        call.enqueue(new Callback<ListContact>() {
            @Override
            public void onResponse(Call<ListContact> call, Response<ListContact> response) {
                ListContact jsonResponse = response.body();
                data = new ArrayList<>(Arrays.asList(jsonResponse.getCont()));

                for(Contact c: data)
                {
                    jsonStr += "Name: "+c.getName()+"\n\n";
                    jsonStr += "Email: "+c.getEmail()+"\n\n";
                    jsonStr += "Mobile: "+c.getMobile()+"\n\n";
                }

            }

            @Override
            public void onFailure(Call<ListContact> call, Throwable t) {

            }
        });
        return jsonStr;
    }
}
