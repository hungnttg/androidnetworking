package com.example.lab3.lab31Asyn;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.TextView;

import com.example.lab3.R;

import java.util.ArrayList;

public class Lab31AsyncAdapter extends BaseAdapter {
    private Context context;
    private ArrayList<Contact> list;
    public Lab31AsyncAdapter(Context context,ArrayList<Contact> list) {
        this.context = context;
        this.list = list;
    }

    @Override
    public int getCount() {
        return list.size();
    }

    @Override
    public Object getItem(int position) {
        return list.get(position);
    }

    @Override
    public long getItemId(int position) {
        return 0;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        Lab31AsyncViewHolder viewHolder;
        if(convertView==null)//chua ton tai
        {
            viewHolder = new Lab31AsyncViewHolder();
            LayoutInflater inflater =
                    (LayoutInflater)context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
            convertView = inflater.inflate(R.layout.lab31async_convertview,null);
            viewHolder.txtID = (TextView)convertView.findViewById(R.id.textView1_lab31async);
            viewHolder.txtName = (TextView)convertView.findViewById(R.id.textView2_lab31async);
            viewHolder.txtMobile = (TextView)convertView.findViewById(R.id.textView3_lab31async);
            convertView.setTag(viewHolder);
        }
        else
        {
            viewHolder = (Lab31AsyncViewHolder)convertView.getTag();
        }
        viewHolder.txtID.setText(list.get(position).getId());
        viewHolder.txtName.setText(list.get(position).getName());
        viewHolder.txtMobile.setText(list.get(position).getMobile());
        return convertView;
    }
    public class Lab31AsyncViewHolder {
        TextView txtID, txtName,txtMobile;
    }
}
