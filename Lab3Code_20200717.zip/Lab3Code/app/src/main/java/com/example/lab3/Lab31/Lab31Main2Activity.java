package com.example.lab3.Lab31;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.ListView;

import com.example.lab3.R;

public class Lab31Main2Activity extends AppCompatActivity {
    ListView listView;
    Lab31AsyncTask asyncTask;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_lab31_main2);

        listView = findViewById(R.id.l31listview);
        asyncTask = new Lab31AsyncTask(this,listView);
        asyncTask.execute();
    }
}
