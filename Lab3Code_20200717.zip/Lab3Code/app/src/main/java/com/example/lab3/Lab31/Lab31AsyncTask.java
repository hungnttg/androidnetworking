package com.example.lab3.Lab31;

import android.content.Context;
import android.os.AsyncTask;
import android.widget.ListView;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;

public class Lab31AsyncTask extends AsyncTask<Void, Void, Void> {

    public static String url="http://192.168.40.101/API-L2-NKW/Lab3/index.php";
    ArrayList<Contact> contactList;
    ListView listView;
    Context context;
    ContactAdapter adapter;
    public Lab31AsyncTask(Context context, ListView listView)
    {
        this.listView = listView;
        this.context = context;
        contactList = new ArrayList<>();
    }

    @Override
    protected void onPostExecute(Void aVoid) {
        super.onPostExecute(aVoid);
        adapter = new ContactAdapter(context,contactList);
        listView.setAdapter(adapter);
    }

    @Override
    protected Void doInBackground(Void... voids) {
        HttpHandler handler = new HttpHandler();
        String jsonStr = handler.convertStreamToString(url);
        if(jsonStr!=null)
        {
            try {
                JSONObject jsonObject = new JSONObject(jsonStr);
                JSONArray contacts = jsonObject.getJSONArray("contacts");
                for(int i=0;i<contacts.length();i++)
                {
                    JSONObject c = contacts.getJSONObject(i);
                    String id = c.getString("id");
                    String name = c.getString("name");
                    String email = c.getString("email");
                    String address = c.getString("address");
                    String gender = c.getString("gender");

                    JSONObject phone = c.getJSONObject("phone");
                    String mobile = phone.getString("mobile");
                    String home = phone.getString("home");
                    String office= phone.getString("office");

                    Contact contact = new Contact();
                    contact.setId(id);
                    contact.setName(name);
                    contact.setEmail(email);
                    contact.setMobile(mobile);
                    contactList.add(contact);
                }
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
        return null;
    }
}
