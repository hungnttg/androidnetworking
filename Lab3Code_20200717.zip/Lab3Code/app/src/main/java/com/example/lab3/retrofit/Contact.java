package com.example.lab3.retrofit;

public class Contact {
    private String name;
    private String email;
    private String mobile;

    public String getName() {
        return name;
    }

    public String getEmail() {
        return email;
    }

    public String getMobile() {
        return mobile;
    }
}
