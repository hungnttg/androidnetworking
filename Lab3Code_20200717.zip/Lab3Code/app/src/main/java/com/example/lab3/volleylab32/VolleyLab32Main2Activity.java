package com.example.lab3.volleylab32;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.TextView;

import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonArrayRequest;
import com.android.volley.toolbox.Volley;
import com.example.lab3.R;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

public class VolleyLab32Main2Activity extends AppCompatActivity {
    TextView textView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_volley_lab32_main2);
        textView = findViewById(R.id.textView_volleylab32);
        getJSON();

    }
    String jsonStr=null;
    public void getJSON()
    {
        RequestQueue queue = Volley.newRequestQueue(this);
        String url = "https://batdongsanabc.000webhostapp.com/mob403lab3/person_array.json";
        JsonArrayRequest req = new JsonArrayRequest(url, new Response.Listener<JSONArray>() {
            @Override
            public void onResponse(JSONArray response) {
                for(int i=0;i<response.length();i++)
                {
                    try {
                        JSONObject person = response.getJSONObject(i);
                        String name = person.getString("name");
                        String email = person.getString("email");
                        JSONObject phone = person.getJSONObject("phone");
                        String home = phone.getString("home");
                        String mobile = phone.getString("mobile");
                        jsonStr += "Name: "+name+"\n\n";
                        jsonStr += "Email: "+email+"\n\n";
                        jsonStr += "phone: "+phone+"\n\n";
                        jsonStr += "Mobile: "+mobile+"\n\n";
                    } catch (JSONException e) {
                        e.printStackTrace();
                    }
                }
                textView.setText(jsonStr);
            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                error.getMessage();
            }
        });
        queue.add(req);
    }
}
