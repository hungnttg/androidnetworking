package com.example.lab3.async;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.ListView;

import com.example.lab3.R;

public class Lab301Main2Activity extends AppCompatActivity {
    ListView listView;
    String link="https://batdongsanabc.000webhostapp.com/mob403lab3/index.php";
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_lab301_main2);

        listView = findViewById(R.id.listview_lab301);
        Lab301AsyncTask lab301AsyncTask = new Lab301AsyncTask(this,link,listView);
        lab301AsyncTask.execute();

    }
}
