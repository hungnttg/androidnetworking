package com.example.lab3.retrofit;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.TextView;

import com.example.lab3.R;

public class RetrofitMain2Activity extends AppCompatActivity {
    TextView textView;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_retrofit_main2);
        textView = findViewById(R.id.textView_lab33Retrofit);
        LoadData d = new LoadData();
        String jsonStr = d.loadJSON1();
        textView.setText(jsonStr);
    }
}
