package com.example.lab3.async;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.TextView;

import com.example.lab3.Lab31.ContactAdapter;
import com.example.lab3.R;

import java.util.ArrayList;
import java.util.List;

public class CustomAdapter extends BaseAdapter {

    Context context;
    ArrayList<Contact> contacts;
    public CustomAdapter(Context context, ArrayList<Contact> contacts) {
        this.context = context;
        this.contacts = contacts;
    }

    @Override
    public int getCount() {
        return contacts.size();
    }

    @Override
    public Object getItem(int position) {
        return contacts.get(position);
    }

    @Override
    public long getItemId(int position) {
        return 0;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        HolderView holderView;
        if(convertView==null)
        {
            holderView = new HolderView();
            LayoutInflater inflater = (LayoutInflater)context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
            convertView=inflater.inflate(R.layout.lab301_converview,null);
           holderView.tvId = (TextView)convertView.findViewById(R.id.textView1_lab301);
           holderView.tvName = (TextView)convertView.findViewById(R.id.textView2_lab301);
           holderView.tvEmail = (TextView)convertView.findViewById(R.id.textView3_lab301);
            convertView.setTag(holderView);
        }
        else
        {
            holderView=(HolderView) convertView.getTag();
        }

        holderView.tvId.setText(contacts.get(position).getId());
        holderView.tvName.setText(contacts.get(position).getName());
        holderView.tvEmail.setText(contacts.get(position).getEmail());
        return convertView;
    }
    public static class HolderView{
        TextView tvId, tvName, tvEmail;
    }
}
