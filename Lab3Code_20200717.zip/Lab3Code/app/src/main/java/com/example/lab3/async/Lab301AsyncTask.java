package com.example.lab3.async;

import android.content.Context;
import android.os.AsyncTask;
import android.widget.ListView;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.ArrayList;
import java.util.List;

public class Lab301AsyncTask extends AsyncTask<Void,Void,Void> {
    CustomAdapter adapter;
    Context context;
    String link;//https://batdongsanabc.000webhostapp.com/mob403lab3/index.php
    ListView listView;
    String jsonStr=null;
    ArrayList<Contact> contactArrayList = new ArrayList<>();

    public Lab301AsyncTask(Context context, String link, ListView listView) {
        this.context = context;
        this.link = link;
        this.listView = listView;
    }

    @Override
    protected void onPostExecute(Void aVoid) {
        super.onPostExecute(aVoid);
        adapter = new CustomAdapter(context,contactArrayList);
        listView.setAdapter(adapter);
    }

    @Override
    protected Void doInBackground(Void... voids) {
        try {
            URL url = new URL(link);
            HttpURLConnection urlConnection = (HttpURLConnection)url.openConnection();
            BufferedReader br =
                    new BufferedReader(new InputStreamReader(urlConnection.getInputStream()));
            StringBuffer sb = new StringBuffer();
            String line="";
            while ((line = br.readLine())!=null)
            {
                sb.append(line);
            }
            jsonStr = sb.toString();
            ///
            JSONObject jsonObject = new JSONObject(jsonStr);
            JSONArray jsonArray = jsonObject.getJSONArray("contacts");
            for(int i=0;i<jsonArray.length();i++)
            {
                JSONObject c = jsonArray.getJSONObject(i);
                String id = c.getString("id");
                String name = c.getString("name");
                String email = c.getString("email");

                JSONObject phone = c.getJSONObject("phone");
                    String mobile = phone.getString("mobile");


                Contact contact = new Contact();
                contact.setId(id);
                contact.setName(name);
                contact.setEmail(email);
                contactArrayList.add(contact);
            }

            urlConnection.disconnect();
        } catch (Exception e) {
            e.printStackTrace();
        }
        return null;
    }
}
