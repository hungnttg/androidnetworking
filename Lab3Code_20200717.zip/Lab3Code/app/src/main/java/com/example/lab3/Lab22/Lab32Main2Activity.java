package com.example.lab3.Lab22;

import androidx.appcompat.app.AppCompatActivity;

import android.nfc.Tag;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import com.android.volley.Request;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.VolleyLog;
import com.android.volley.toolbox.JsonArrayRequest;
import com.android.volley.toolbox.JsonObjectRequest;
import com.example.lab3.R;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

public class Lab32Main2Activity extends AppCompatActivity {
    private String urlJsonObj = "http://192.168.40.101/API-L2-NKW/Lab3/person_object.json";
    private String urlJsonArr = "http://192.168.40.101/API-L2-NKW/Lab3/person_array.json";

    private Button btnObject, btnArray;
    private TextView txtResponse;
    private String jsonResponse;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_lab32_main2);

        btnObject = findViewById(R.id.lab32btnObj);
        btnArray = findViewById(R.id.lab32btnArray);
        txtResponse = findViewById(R.id.lab32tvKetqua);
        btnArray.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                makeJsonArray();
            }
        });

        btnObject.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                makeJsonObject();
            }
        });
    }
    public void makeJsonObject()
    {
        JsonObjectRequest jsonObjReq =
                new JsonObjectRequest(Request.Method.GET, urlJsonObj, null,
                        new Response.Listener<JSONObject>() {
                            @Override
                            public void onResponse(JSONObject response) {
                                try {
                                    String name = response.getString("name");
                                    String email = response.getString("email");
                                    JSONObject phone = response.getJSONObject("phone");
                                    String home = phone.getString("home");
                                    String mobile = phone.getString("mobile");

                                    jsonResponse="";
                                    jsonResponse += "Name: "+name+"\n\n";
                                    jsonResponse += "Email: "+email+"\n\n";
                                    jsonResponse += "Home: "+home+"\n\n";
                                    jsonResponse += "Mobile: "+mobile+"\n\n";

                                    txtResponse.setText(jsonResponse);
                                } catch (JSONException e) {
                                    e.printStackTrace();
                                }
                            }
                        }, new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {
                        VolleyLog.d("LOI",error.getMessage());
                    }
                });

        AppController.getInstance().addToRequestQueue(jsonObjReq);
    }
    public void makeJsonArray()
    {
        JsonArrayRequest jsonArrayRequest = new JsonArrayRequest(
                urlJsonArr,
                new Response.Listener<JSONArray>() {
                    @Override
                    public void onResponse(JSONArray response) {
                        for(int i=0;i<response.length();i++)
                        {
                            try {
                                JSONObject object = (JSONObject)response.get(i);
                                String name = object.getString("name");
                                String email = object.getString("email");
                                JSONObject phone = object.getJSONObject("phone");
                                String home = phone.getString("home");
                                String mobile = phone.getString("mobile");

                                jsonResponse="";
                                jsonResponse += "Name: "+name+"\n\n";
                                jsonResponse += "Email: "+email+"\n\n";
                                jsonResponse += "Home: "+home+"\n\n";
                                jsonResponse += "Mobile: "+mobile+"\n\n";

                                txtResponse.setText(jsonResponse);
                            } catch (JSONException e) {
                                e.printStackTrace();
                            }

                        }
                    }
                },
                new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {
                        VolleyLog.d("LOI",error.getMessage());
                    }
                }
        );
    }
}
