<?php
    $canh = $_POST['canh'];//user gui den server bang phuongthuc POST
    $thetich = pow($canh,3);//server tinh toan du lieu
    echo "The tich la: ".$thetich;//server tra ve cho client
?>