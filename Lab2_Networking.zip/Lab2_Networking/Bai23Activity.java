package com.example.androidnetwork.Lab2;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import com.example.androidnetwork.R;

public class Bai23Activity extends AppCompatActivity implements View.OnClickListener{
    public static final String SERVER_NAME = "http://192.168.165.2:81/android_server/canh_POST.php";

    private EditText edtCanh;
    private Button btnSend;
    private TextView tvResult;
    String strCanh;
    BackgroundTask_POST bPost;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_bai23);
        edtCanh = (EditText) findViewById(R.id.edtCanh);
        btnSend = (Button) findViewById(R.id.btnSend);
        tvResult = (TextView) findViewById(R.id.tvResult);
        btnSend.setOnClickListener(this);
    }

    @Override
    public void onClick(View v) {
        switch (v.getId()){
            case R.id.btnSend:
                strCanh = edtCanh.getText().toString();
                bPost = new BackgroundTask_POST(this,strCanh,strCanh,tvResult);
                bPost.execute();
        }
    }
}
