package com.example.androidnetwork.Lab2;

import android.app.ProgressDialog;
import android.content.Context;
import android.os.AsyncTask;
import android.widget.TextView;

import com.example.androidnetwork.MainActivity;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLEncoder;

public class Bai4_BackgroundTask_POST extends AsyncTask<String, Void, Void> {

    String duongdan = Bai24Activity.SERVER_NAME;
    Context context;
    TextView tvResult;
    String strResult;
    ProgressDialog pDialog;

    public Bai4_BackgroundTask_POST(Context context, TextView tvResult){
        this.context = context;
        this.tvResult = tvResult;
    }

    @Override
    protected void onPreExecute() {
        super.onPreExecute();
        pDialog = new ProgressDialog(context);
        pDialog.setMessage("Đang tính toán...");
        pDialog.setIndeterminate(false);
        pDialog.setCancelable(false);
        pDialog.show();
    }

    @Override
    protected Void doInBackground(String... params) {
        try {
            URL url = new URL(duongdan);
            String param =
                    "a=" + URLEncoder.encode(params[0].toString(), "utf-8") +
                    "&b=" + URLEncoder.encode(params[1].toString(), "utf-8") +
                    "&c=" + URLEncoder.encode(params[2].toString(), "utf-8");
            HttpURLConnection urlConnection = (HttpURLConnection) url.openConnection();
            urlConnection.setDoOutput(true);
            urlConnection.setRequestMethod("POST");
            urlConnection.setFixedLengthStreamingMode(param.getBytes().length);
            urlConnection.setRequestProperty("Content-Type",
                    "application/x-www-form-urlencoded");

            PrintWriter print = new PrintWriter(urlConnection.getOutputStream());
            print.print(param);
            print.close();

            String line = "";
            BufferedReader bfr = new BufferedReader
                    (new InputStreamReader(urlConnection.getInputStream()));
            StringBuffer sb = new StringBuffer();
            while ((line = bfr.readLine()) != null){
                sb.append(line);
            }
            strResult = sb.toString();
            urlConnection.disconnect();
        } catch (Exception e){
            e.printStackTrace();
        }
        return null;
    }

    @Override
    protected void onPostExecute(Void result) {
        super.onPostExecute(result);
        if(pDialog.isShowing()){
            pDialog.dismiss();
        }
        tvResult.setText(strResult);
    }
}

