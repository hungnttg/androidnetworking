<?php
//bien co dau $
//dau noi chuoi: .
$name=$_GET['name'];//lay du lieu tu client gui len
$mark = $_GET['mark'];//lay du lieu tu client gui len
echo "Ten: ".$name." ; Diem: ".$mark;
?>