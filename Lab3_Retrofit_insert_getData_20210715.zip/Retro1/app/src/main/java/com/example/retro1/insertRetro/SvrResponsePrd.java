package com.example.retro1.insertRetro;

public class SvrResponsePrd { //GET
    private Prd products;
    private String message;
    private String result;

    public Prd getProducts() {
        return products;
    }

    public String getMessage() {
        return message;
    }

    public String getResult() {
        return result;
    }
}
