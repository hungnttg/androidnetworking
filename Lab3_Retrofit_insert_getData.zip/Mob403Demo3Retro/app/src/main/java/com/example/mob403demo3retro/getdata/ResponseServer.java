package com.example.mob403demo3retro.getdata;

public class ResponseServer {//server tra ve (GET)
    private Products[] products;
    private String message;
    private String result;

    public Products[] getProducts() {
        return products;
    }

    public String getMessage() {
        return message;
    }

    public String getResult() {
        return result;
    }
}
