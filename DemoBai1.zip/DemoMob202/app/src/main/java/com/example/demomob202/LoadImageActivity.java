package com.example.demomob202;

import androidx.appcompat.app.AppCompatActivity;

import android.graphics.Bitmap;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

import java.net.URL;

public class LoadImageActivity extends AppCompatActivity
implements View.OnClickListener, LoadImageInterface{
    TextView tvMsg;
    Button btnLoad;
    ImageView img;
    public static final String URL = "";
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_load_image);
        tvMsg = findViewById(R.id.textView);
        btnLoad = findViewById(R.id.button);
        img = findViewById(R.id.imageView2);
        btnLoad.setOnClickListener(this);
    }

    @Override
    public void onClick(View v) {
        //goi ham trong asynctask
        new LoadImageAsync(this,this).execute(URL);
    }
    //post len client
    @Override
    public void onImageLoaded(Bitmap bitmap) {
        img.setImageBitmap(bitmap);

    }

    @Override
    public void onError() {
        tvMsg.setText("Co loi khi download");
    }
}