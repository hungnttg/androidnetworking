package com.example.demomob202;

import android.graphics.Bitmap;

public interface LoadImageInterface {
    void onImageLoaded(Bitmap bitmap);
    void onError();
}
