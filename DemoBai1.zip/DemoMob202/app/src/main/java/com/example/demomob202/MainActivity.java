package com.example.demomob202;

import androidx.appcompat.app.AppCompatActivity;

import android.app.ProgressDialog;
import android.graphics.Bitmap;

import android.graphics.BitmapFactory;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.provider.ContactsContract;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

import java.net.MalformedURLException;
import java.net.URL;

public class MainActivity extends AppCompatActivity
implements View.OnClickListener{
    Button btn11;
    ImageView img11;
    TextView txt11;
    //hien thi tien trinh download
    //server uy nhiem cho ProgressDialog
    ProgressDialog progressDialog;
    Bitmap b;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        btn11 = findViewById(R.id.btn11);
        img11 = findViewById(R.id.img11);
        txt11 = findViewById(R.id.txt11);
        btn11.setOnClickListener(this);
    }
    //ham uy nhiem
    Handler msgHandler = new Handler(){
        public void handlerMessage(Message msg)
        {
            super.handleMessage(msg);
            Bundle bundle = msg.getData();
            String message = bundle.getString("message");
            txt11.setText(message);
            img11.setImageBitmap(b);
            progressDialog.dismiss();
        }
    };
    //dinh nghia ham
    public Bitmap loadImage(String str)
    {
        Bitmap b = null;
        URL url;
        try {
            url = new URL(str);//lay ve duong dan anh
            //chuyen sang bitmap
            b = BitmapFactory.decodeStream(url.openConnection().getInputStream());
        } catch (Exception e) {
            e.printStackTrace();
        }
        return b;//tra ve ket qua
    }

    @Override
    public void onClick(View v) {
        //thuc hien xu ly voi thread: doc du lieu tu server -? dua len client
        final Thread t1 = new Thread(new Runnable() {
            @Override
            public void run() {
                //lay du lieu ve
               final Bitmap b = loadImage("http://i164.tinypic.com/28vaq8k.png");
                //day du lieu len client
                img11.post(new Runnable() {
                    @Override
                    public void run() {
                        txt11.setText("down thanh cong");
                        img11.setImageBitmap(b);
                    }
                });

            }
        });
        t1.start();//bat dau thuc hien tien trinh
    }
}