package com.example.demomob202;

import android.app.ProgressDialog;
import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.AsyncTask;

import java.io.IOException;
import java.io.InputStream;
import java.net.URL;

public class LoadImageAsync extends AsyncTask<String,Void,Bitmap> {
    LoadImageInterface mListener;
    ProgressDialog progressDialog;
    public LoadImageAsync(LoadImageInterface listener, Context context)
    {
        mListener = listener;
        progressDialog = new ProgressDialog(context);
    }
    //xu ly dau vao -> lay ra duoc anh
    @Override
    protected Bitmap doInBackground(String... strings) {
        try
        {
            return BitmapFactory.decodeStream((InputStream)new URL(strings[0]).getContent());
        }
        catch (IOException e)
        {
            e.printStackTrace();
        }
        return null;
    }
    //dau ra -> dua anh len client
    @Override
    protected void onPostExecute(Bitmap s) {
        super.onPostExecute(s);
      if(progressDialog.isShowing()){
          progressDialog.dismiss();
      }
      if(s!=null)
      {
          mListener.onImageLoaded(s);//dua anh len
      }
      else
      {
          mListener.onError();
      }
    }
    //ham xu ly qua trinh
    @Override
    protected void onPreExecute() {
        super.onPreExecute();
        progressDialog.setMessage("chung toi dang download du lieu");
        progressDialog.show();
    }
}
