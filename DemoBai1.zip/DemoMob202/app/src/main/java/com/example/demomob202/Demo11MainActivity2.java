package com.example.demomob202;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class Demo11MainActivity2 extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_demo11_main2);
    }
}