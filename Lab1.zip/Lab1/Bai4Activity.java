package com.example.androidnetwork.Lab1;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import com.example.androidnetwork.R;

public class Bai4Activity extends AppCompatActivity
        implements View.OnClickListener{

    private EditText edtTime;
    private Button btnRun;
    private TextView tvResult;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_bai4);
        edtTime = (EditText) findViewById(R.id.edtTime);
        btnRun = (Button) findViewById(R.id.btnRun);
        tvResult = (TextView) findViewById(R.id.tvResult);
        btnRun.setOnClickListener(this);
    }

    @Override
    public void onClick(View v) {
        switch (v.getId()){
            case R.id.btnRun:
                Bai4AsyncTaskRunner asyncTaskRunner =
                        new Bai4AsyncTaskRunner(this, tvResult, edtTime);
                String sleepTime = edtTime.getText().toString();
                asyncTaskRunner.execute(sleepTime);
                break;
        }
    }
}
