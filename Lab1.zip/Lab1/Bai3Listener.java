package com.example.androidnetwork.Lab1;

import android.graphics.Bitmap;

public interface Bai3Listener{
    void onImageLoaded(Bitmap bitmap);
    void onError();
}