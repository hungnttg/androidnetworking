package com.example.androidnetwork.Lab1;

import androidx.appcompat.app.AppCompatActivity;

import android.app.ProgressDialog;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

import com.example.androidnetwork.R;

import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;

public class Bai2Activity extends AppCompatActivity
        implements View.OnClickListener{

    private ImageView imgAndroid;
    private Button btnLoad;
    private ProgressDialog progressDialog;
    private String url = "http://i64.tinypic.com/28vaq8k.png";
    private Bitmap bitmap = null;
    private TextView tvMessage;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_bai2);
        imgAndroid = (ImageView) findViewById(R.id.imgAndroid);
        btnLoad = (Button) findViewById(R.id.btnLoad_lab12222);
        tvMessage = (TextView) findViewById(R.id.tvMessage_lab12);
        btnLoad.setOnClickListener(this);
    }
//2
    private Handler messageHandler = new Handler(){
        public void handleMessage(Message msg){
            super.handleMessage(msg);
            Bundle bundle = msg.getData();
            String message = bundle.getString("message");
            tvMessage.setText(message);
            imgAndroid.setImageBitmap(bitmap);
            progressDialog.dismiss();
        }
    };
//1
    @Override
    public void onClick(View v) {
        progressDialog = ProgressDialog.show(Bai2Activity.this, "",
                "Đang Download...");
        Runnable aRunnable = new Runnable() {
            @Override
            public void run() {
                bitmap = downloadBitmap(url);
                Message msg = messageHandler.obtainMessage();
                Bundle bundle = new Bundle();
                String threadMessage = "Đã dowload xong ảnh Ngọc Trinh";
                bundle.putString("message", threadMessage);
                msg.setData(bundle);
                messageHandler.sendMessage(msg);
            }
        };
        Thread aThread = new Thread(aRunnable);
        aThread.start();
    }

    private Bitmap downloadBitmap(String link){
        try {
            URL url = new URL(link);
            HttpURLConnection connection = (HttpURLConnection) url.openConnection();
            connection.connect();
            InputStream inputStream = connection.getInputStream();
            Bitmap bitmap = BitmapFactory.decodeStream(inputStream);
            return  bitmap;
        } catch (Exception e){
            e.printStackTrace();
        }
        return null;
    }
}
