package com.example.androidnetwork.Lab1;

import androidx.appcompat.app.AppCompatActivity;

import android.graphics.Bitmap;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

import com.example.androidnetwork.R;

public class Bai3Activity extends AppCompatActivity implements
        View.OnClickListener, Bai3Listener{

    private TextView tvMessage;
    private Button btnLoad;
    private ImageView imgLoad;

    public static final
    String IMAGE_URL = "http://sohanews.sohacdn.com/2016/photo-2-1465288075049.jpg";
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_bai3);
        tvMessage = (TextView) findViewById(R.id.tvMessage_lab1222);
        btnLoad = (Button) findViewById(R.id.btnLoad_lab12222);
        imgLoad = (ImageView) findViewById(R.id.imgLoad);
        btnLoad.setOnClickListener(this);
    }

    @Override
    public void onClick(View arg0) {
        switch (arg0.getId()){
            case R.id.btnLoad_lab12222:
                new Bai3LoadImageTask(this,this).execute(IMAGE_URL);
                break;
        }
    }


    @Override
    public void onImageLoaded(Bitmap bitmap) {
        imgLoad.setImageBitmap(bitmap);
        tvMessage.setText("Đã Download xong ảnh");
    }

    @Override
    public void onError() {
        tvMessage.setText("Có lỗi khi Download Ảnh");
    }
}

