package com.example.demo2mob403;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.QuickContactBadge;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {
    public static final String SERVER_URL = "http://192.168.40.105/mob403/lab2/sinhvien_GET.php";
    Button button;
    EditText txtName,txtScore;
    TextView tvResult;
    String sname,sscore;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        txtName = findViewById(R.id.txtName);
        txtScore = findViewById(R.id.txtScore);
        tvResult = findViewById(R.id.tvResult);
        button = findViewById(R.id.btnGet);
        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                sname = txtName.getText().toString();
                sscore = txtScore.getText().toString();
                //goi ham xu ly du lieu
                AsynGet a = new AsynGet(MainActivity.this,tvResult,sname,sscore);
                a.execute();//thuc thi
            }
        });
    }
}
