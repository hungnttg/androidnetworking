package com.example.demo2mob403;

import android.app.ProgressDialog;
import android.content.Context;
import android.os.AsyncTask;
import android.widget.TextView;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.URL;

public class AsynGet extends AsyncTask<Void,Void,Void> {
    String path = MainActivity.SERVER_URL;
    TextView tvKQ;
    String str;//chuoi kq
    ProgressDialog dialog;
    String strName,strScore;//chua du lieu
    Context context;
    public AsynGet(Context context,TextView tvKQ,String strName,String strScore)
    {
        this.context = context;
        this.tvKQ = tvKQ;
        this.strName = strName;
        this.strScore = strScore;
    }
    //lay du lieu o server
    @Override
    protected Void doInBackground(Void... voids) {
        path +="?name="+this.strName+"&score="+this.strScore;//truyen tham so vao duong dan
        try{
            URL url = new URL(path);
            //doc du lieu va chuyen vao bo dem
            BufferedReader br = new BufferedReader(new InputStreamReader(url.openConnection().getInputStream()));
            //doc tu bo dem ra
            String dem = "";
            StringBuffer sb = new StringBuffer();
            while ((dem=br.readLine())!=null)//neu khong phai la cuoi bo dem
            {
                sb.append(dem);//dua du lieu bo dem vao sb
            }
            str = sb.toString();//chuyen sb sang dang chuoi
        }
        catch (Exception e)
        {
            e.printStackTrace();
        }
        return null;
    }
    //qua trinh xu ly
    @Override
    protected void onPreExecute() {
        super.onPreExecute();
        dialog = new ProgressDialog(context);
        dialog.setMessage("sang xu ly......");
        dialog.setIndeterminate(false);
        dialog.setCancelable(false);
        dialog.show();
    }
    //dua du lieu ve client

    @Override
    protected void onPostExecute(Void aVoid) {
        super.onPostExecute(aVoid);
        if(dialog.isShowing())
        {
            dialog.dismiss();
        }
        tvKQ.setText(str);
    }
}
