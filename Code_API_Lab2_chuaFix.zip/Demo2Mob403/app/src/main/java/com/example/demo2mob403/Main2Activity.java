package com.example.demo2mob403;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

public class Main2Activity extends AppCompatActivity {
    public static final String SERVER_URL = "http://192.168.40.105/mob403/lab2/giaiphuongtrinh_post.php";
    EditText txtA,txtB,txtC;
    Button btnTinh;
    TextView tvKQTinh;
    String a,b,c;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main2);
        txtA = findViewById(R.id.txtA);
        txtB = findViewById(R.id.txtB);
        txtC = findViewById(R.id.txtC);
        btnTinh = findViewById(R.id.btnTinh);
        tvKQTinh = findViewById(R.id.tvKQTinh);
        btnTinh.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                a = txtA.getText().toString();
                b = txtB.getText().toString();
                c = txtC.getText().toString();
                new Post_GPT(Main2Activity.this,tvKQTinh).execute(a,b,c);

            }
        });
    }
}
