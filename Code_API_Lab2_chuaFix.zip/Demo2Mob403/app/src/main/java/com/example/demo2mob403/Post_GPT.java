package com.example.demo2mob403;

import android.app.ProgressDialog;
import android.content.Context;
import android.os.AsyncTask;
import android.widget.TextView;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLEncoder;

public class Post_GPT extends AsyncTask<String,Void,Void> {
    String path = "";
    Context context;
    TextView tvKQ;
    String str;
    ProgressDialog dialog;
    public Post_GPT(Context context,TextView tvKQ)
    {
        this.context = context;
        this.tvKQ = tvKQ;
    }
    @Override
    protected Void doInBackground(String... strings) {
        try {
            URL url = new URL(path);
            //xu ly kieu post
            String thamso =
                    "a="+ URLEncoder.encode(strings[0].toString(),"utf-8")+
                     "&b="+ URLEncoder.encode(strings[1].toString(),"utf-8")+
                     "&c="+ URLEncoder.encode(strings[2].toString(),"utf-8");
            HttpURLConnection connection =
                    (HttpURLConnection)url.openConnection();
            connection.setDoOutput(true);
            connection.setRequestMethod("POST");
            connection.setFixedLengthStreamingMode(thamso.getBytes().length);
            connection.setRequestProperty("Content-Type","application/x-www-form-urlencoded");
            PrintWriter printWriter = new PrintWriter(connection.getOutputStream());
            printWriter.print(thamso);
            printWriter.close();

            //doc du lieu va chuyen vao bo dem
            BufferedReader br = new BufferedReader(new InputStreamReader(connection.getInputStream()));
            //doc tu bo dem ra
            String dem = "";
            StringBuffer sb = new StringBuffer();
            while ((dem=br.readLine())!=null)//neu khong phai la cuoi bo dem
            {
                sb.append(dem);//dua du lieu bo dem vao sb
            }
            str = sb.toString();//chuyen sb sang dang chu
            connection.disconnect();
        }
        catch (Exception e)
        {
            e.printStackTrace();
        }
        return null;
    }

    @Override
    protected void onPreExecute() {
        super.onPreExecute();
        dialog = new ProgressDialog(context);
        dialog.setMessage("sang xu ly......");
        dialog.setIndeterminate(false);
        dialog.setCancelable(false);
        dialog.show();
    }

    @Override
    protected void onPostExecute(Void aVoid) {
        super.onPostExecute(aVoid);
        if(dialog.isShowing())
        {
            dialog.dismiss();
        }
        tvKQ.setText(str);
    }
}
