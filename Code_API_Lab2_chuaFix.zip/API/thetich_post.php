<?php
    $canh = $_POST['canh'];//nhan du lieu tu client gui len dang post
    $thetich = pow($canh,3);
    echo "The tich la: ".$thetich;
?>