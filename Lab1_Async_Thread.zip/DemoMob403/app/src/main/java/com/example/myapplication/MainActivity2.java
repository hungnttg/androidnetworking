package com.example.myapplication;

import androidx.appcompat.app.AppCompatActivity;

import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.AsyncTask;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

import java.io.IOException;
import java.io.InputStream;
import java.net.URL;

public class MainActivity2 extends AppCompatActivity {
    Button button2;
    ImageView imageView2;
    TextView textView2;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main2);
        textView2 = findViewById(R.id.textView2);
        imageView2 = findViewById(R.id.imageView2);
        button2 = findViewById(R.id.button2);
        button2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                new Async2().execute("http://i64.tinypic.com/28vaq8k.png");
            }
        });
    }
    public class Async2 extends AsyncTask<String,Void, Bitmap>{

        @Override
        protected Bitmap doInBackground(String... strings) {
            try {
                //thuc hien lay anh ve tu dung link
                return BitmapFactory.decodeStream((InputStream)new URL(strings[0]).getContent());
            } catch (IOException e) {
                e.printStackTrace();
            }
            return null;
        }
        //xu ly qua trinh
        @Override
        protected void onPreExecute() {
            super.onPreExecute();
        }
        //dua du lieu ve interface
        @Override
        protected void onPostExecute(Bitmap bitmap) {
            super.onPostExecute(bitmap);
            if(bitmap!=null)
            {
                imageView2.setImageBitmap(bitmap);
                textView2.setText("Thanh cong");
            }
            else
            {
                textView2.setText("co loi");
            }
        }
    }
}