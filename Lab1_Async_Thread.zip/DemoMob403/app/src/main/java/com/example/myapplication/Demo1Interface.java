package com.example.myapplication;

import android.graphics.Bitmap;

public interface Demo1Interface {
    void onLoadImg(Bitmap bitmap);//ham load anh
    void onError();//neu xay ra loi
}
