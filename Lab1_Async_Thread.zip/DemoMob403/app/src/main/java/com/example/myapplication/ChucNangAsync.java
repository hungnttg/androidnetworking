package com.example.myapplication;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.AsyncTask;

import java.io.IOException;
import java.io.InputStream;
import java.net.URL;

public class ChucNangAsync extends AsyncTask<String,Void, Bitmap> {
    //doc du lieu tu server
    //nghi cach de dua interface vao day-> truyen ket qua download ve interface
    private Demo1Interface mListener;
    public ChucNangAsync(Demo1Interface listener, Context context)
    {
        mListener = listener;
    }
    @Override
    protected Bitmap doInBackground(String... strings) {
        try {
            //thuc hien lay anh ve tu dung link
            return BitmapFactory.decodeStream((InputStream)new URL(strings[0]).getContent());
        } catch (IOException e) {
            e.printStackTrace();
        }
        return null;
    }
    //xu ly qua trinh
    @Override
    protected void onPreExecute() {
        super.onPreExecute();
    }
    //dua du lieu ve interface
    @Override
    protected void onPostExecute(Bitmap bitmap) {
        super.onPostExecute(bitmap);
        if(bitmap!=null)
        {
            mListener.onLoadImg(bitmap);//dua ket qua ve interface
        }
        else
        {
            mListener.onError();//neu loi thi tra ket qua ve interface
        }
    }
}
