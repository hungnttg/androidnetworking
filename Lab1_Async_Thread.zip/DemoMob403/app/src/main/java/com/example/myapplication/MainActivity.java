package com.example.myapplication;

import androidx.appcompat.app.AppCompatActivity;

import android.graphics.Bitmap;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity implements
        View.OnClickListener,Demo1Interface{
Button button;
ImageView imageView;
TextView textView;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        textView = findViewById(R.id.textView);
        imageView = findViewById(R.id.imageView);
        button = findViewById(R.id.button);
        button.setOnClickListener(this);
    }

    @Override
    public void onClick(View v) {
        //khi click vao button => goi AsysnTask
        //cach goi: dung execute
        new ChucNangAsync(this,this).execute("http://i64.tinypic.com/28vaq8k.png");
    }
    //dien ket qua vao client
    @Override
    public void onLoadImg(Bitmap bitmap) {
        imageView.setImageBitmap(bitmap);
        textView.setText("Thanh cong");
    }

    @Override
    public void onError() {
        textView.setText("Co loi");
    }
}