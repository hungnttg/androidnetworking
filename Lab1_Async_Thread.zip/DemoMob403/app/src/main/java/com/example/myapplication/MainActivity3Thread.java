package com.example.myapplication;

import androidx.appcompat.app.AppCompatActivity;

import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

import java.io.IOException;
import java.net.MalformedURLException;
import java.net.URL;

public class MainActivity3Thread extends AppCompatActivity {
    ImageView imageView3;
    TextView textView3;
    Button button3;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main_activity3_thread);
        imageView3 = findViewById(R.id.imageView3);
        textView3 = findViewById(R.id.textView3);
        button3 = findViewById(R.id.button3);
        button3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                final  Thread myT = new Thread(new Runnable() {
                    @Override
                    public void run() {
                        //thread1
                        final Bitmap bitmap=loadAnh("http://i64.tinypic.com/28vaq8k.png");
                        imageView3.post(new Runnable() {
                            @Override
                            public void run() {
                                //thread 1.1
                                imageView3.setImageBitmap(bitmap);
                                textView3.setText("Thanh cong");
                            }
                        });
                    }
                });
                myT.start();
            }
        });
    }
    private Bitmap loadAnh(String link)
    {
        URL url;
        Bitmap bitmap=null;
        try {
            url = new URL(link);
            bitmap = BitmapFactory.decodeStream(url.openConnection().getInputStream());
        } catch (IOException e) {
            e.printStackTrace();
        }
        return bitmap;
    }
}