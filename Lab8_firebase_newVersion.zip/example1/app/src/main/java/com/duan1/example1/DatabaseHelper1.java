package com.duan1.example1;

import android.text.TextUtils;
import android.widget.TextView;

import androidx.annotation.NonNull;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;
import java.util.List;

public class DatabaseHelper1 {
    private FirebaseDatabase f_instance;
    private DatabaseReference f_db;
    private String USER_ID;
    public void createUser(String name, String email)
    {
        f_instance = FirebaseDatabase.getInstance();
        f_db = f_instance.getReference("user");//ten database
        if(TextUtils.isEmpty(USER_ID))
        {
            USER_ID = f_db.push().getKey();//tao key ngau nhien
        }
        User user = new User(name,email);
        f_db.child(USER_ID).setValue(user);
        Add_UserChangeListen();
    }
    public void updateUser(String name,String email)
    {
        f_instance = FirebaseDatabase.getInstance();
        f_db = f_instance.getReference("user");//ten database
        if(!TextUtils.isEmpty(name))
            f_db.child(USER_ID).child("name").setValue(name);
        if(!TextUtils.isEmpty(email))
            f_db.child(USER_ID).child("email").setValue(email);
        Add_UserChangeListen();
    }
    private void Add_UserChangeListen()
    {
        f_db.child(USER_ID).addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                //lay ve user hien tai
                User user = snapshot.getValue(User.class);
                //lay ve tat ca cac user
                List<User> list = new ArrayList<>();
                for(DataSnapshot d: snapshot.getChildren())
                {
                    User user1 = snapshot.getValue(User.class);
                    list.add(user1);
                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {

            }
        });
    }
}
