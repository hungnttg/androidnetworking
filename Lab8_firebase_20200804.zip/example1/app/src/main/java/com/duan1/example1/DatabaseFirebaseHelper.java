package com.duan1.example1;

import android.text.TextUtils;
import android.widget.TextView;

import androidx.annotation.NonNull;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

public class DatabaseFirebaseHelper {
    private FirebaseDatabase f_instance;
    private DatabaseReference f_db;
    private String USER_ID;
    public void getDB()
    {
        f_instance=FirebaseDatabase.getInstance();
        f_db = f_instance.getReference("user");
        //f_instance.getReference("app_title").setValue("Realtime Database");
        //f_instance.getReference("app_title").addValueEventListener(new ValueEventListener() {
        f_db.child("app_title").setValue("Realtime Database");
        f_db.child("app_title").addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                //ket qua them vao: title
                String title=snapshot.getValue(String.class);
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {

            }
        });
    }
    public void createUser(String name, String email,TextView tvResult)
    {
        if(TextUtils.isEmpty(USER_ID))
        {
            USER_ID=f_db.push().getKey();
        }
        User user = new User(name,email);
        f_db.child(USER_ID).setValue(user);
        Add_UserChangeListener(tvResult);
    }
    public void updateUser(String name,String email,TextView tvResult)
    {
        if(!TextUtils.isEmpty(name))
        {
            f_db.child(USER_ID).child("name").setValue(name);
            Add_UserChangeListener(tvResult);
        }
        if(!TextUtils.isEmpty(email))
        {
            f_db.child(USER_ID).child("email").setValue(email);
            Add_UserChangeListener(tvResult);
        }
    }
    public void Add_UserChangeListener(final TextView tvResult)
    {
        f_db.child(USER_ID).addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                User user = snapshot.getValue(User.class);
                //hien thi thong tin user THAY DOI o day
                tvResult.setText(user.getName()+"--"+user.getEmail());
                //tvResult.setText....
                //foreach cac user o day
                for(DataSnapshot d:snapshot.getChildren())
                {
                    int i=1;
                    User user1 = snapshot.getValue(User.class);
                    //log...
                    i++;
                }

            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {
                tvResult.setText("Loi");
            }
        });
    }
}
