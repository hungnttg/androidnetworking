<?php

//require_once 'include/DB_Functions.php';
//$db = new DB_Functions();
//require('../../admin/db_login.php');
$host="localhost";
$username="root";
$password="";
$db_name="android_api";

 

$mysqli=mysqli_connect($host, $username, $password,$db_name) or die('Could not connect');
//mysqli_select_db($db_name, $db) or die('');

$myArray = array();
    if ($result = $mysqli->query("SELECT * FROM movies")) {
        $tempArray = array();
        while($row = $result->fetch_object()) {
                $tempArray = $row;
                array_push($myArray, $tempArray);
            }
        echo '{ "movies":';
        echo json_encode($myArray);
        echo '}';
    }

    $result->close();
    $mysqli->close();