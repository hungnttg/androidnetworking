<?php
	$canh=$_POST['canh'];
	$thetich = pow($canh,3);
	
	echo "The tich " . $thetich;
?>