<?php
	$name=$_GET['name'];
	$score=$_GET['score'];
	echo "Name: " . $name . "; Score: " .$score;
?>