package com.example.retro1.DeleteData;

import android.widget.TextView;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;
import retrofit2.Retrofit;
import retrofit2.converter.gson.GsonConverterFactory;

public class DeleteFunction {
    public void deleteFn(TextView tvResult, String pid)
    {
        Retrofit retrofit = new Retrofit.Builder()
                .baseUrl(ConstDelete.BASE_URL)
                .addConverterFactory(GsonConverterFactory.create())
                .build();
        PrdDelete p = new PrdDelete();
        p.setPid(pid);
        //
        RequestDelete requestDelete = new RequestDelete();
        requestDelete.setProducts(p);
        //
        InterfaceDelete interfaceDelete = retrofit.create(InterfaceDelete.class);
        Call<ResponseDelete> call = interfaceDelete.deleteExe(pid);
        //
        call.enqueue(new Callback<ResponseDelete>() {
            @Override
            public void onResponse(Call<ResponseDelete> call, Response<ResponseDelete> response) {
                ResponseDelete responseDelete = response.body();
                tvResult.setText(responseDelete.getMessage());
            }

            @Override
            public void onFailure(Call<ResponseDelete> call, Throwable t) {
                tvResult.setText(t.getMessage());
            }
        });
    }
}
