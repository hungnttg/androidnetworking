package com.example.retro1.DeleteData;

public class RequestDelete {//set
    private PrdDelete products;
    private String operation;

    public void setProducts(PrdDelete products) {
        this.products = products;
    }

    public void setOperation(String operation) {
        this.operation = operation;
    }
}
