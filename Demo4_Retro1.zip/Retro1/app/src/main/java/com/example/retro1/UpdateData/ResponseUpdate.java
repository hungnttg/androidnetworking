package com.example.retro1.UpdateData;

public class ResponseUpdate {//GET
    private PrdUpdate products;
    private String message;
    private String result;

    public PrdUpdate getProducts() {
        return products;
    }

    public String getMessage() {
        return message;
    }

    public String getResult() {
        return result;
    }
}
