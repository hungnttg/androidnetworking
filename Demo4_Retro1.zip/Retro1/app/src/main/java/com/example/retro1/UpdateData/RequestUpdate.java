package com.example.retro1.UpdateData;

public class RequestUpdate {//set
    private PrdUpdate products;
    private String operation;//

    public void setProducts(PrdUpdate products) {
        this.products = products;
    }

    public void setOperation(String operation) {
        this.operation = operation;
    }
}
