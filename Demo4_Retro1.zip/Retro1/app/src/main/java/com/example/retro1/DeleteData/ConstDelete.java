package com.example.retro1.DeleteData;

public class ConstDelete {
    public static final String BASE_URL="https://batdongsanabc.000webhostapp.com/mob403lab5/";
}
