package com.example.retro1.GetDataJSon;

import retrofit2.Call;
import retrofit2.http.GET;

public interface InterfaceGetData {
    @GET("getall.json")
    Call<SrvResponseProducts> GetJSON();
}
