package com.example.retro1.GetDataJSon;
/**/
public class SrvResponseProducts {//GET
    private Products[] products;//products khong thay doi
    private String message;
    private String result;

    public Products[] getProducts() {
        return products;
    }

    public String getMessage() {
        return message;
    }

    public String getResult() {
        return result;
    }
}
