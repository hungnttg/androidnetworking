package com.example.retro1;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import com.example.retro1.DeleteData.DeleteFunction;
import com.example.retro1.GetDataJSon.InterfaceGetData;
import com.example.retro1.GetDataJSon.Products;
import com.example.retro1.GetDataJSon.SrvResponseProducts;
import com.example.retro1.UpdateData.FunctionUpdate;
import com.example.retro1.UpdateData.PrdUpdate;
import com.example.retro1.insertRetro.InterInsertPrd;
import com.example.retro1.insertRetro.Prd;
import com.example.retro1.insertRetro.SvrResponsePrd;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;
import retrofit2.Retrofit;
import retrofit2.converter.gson.GsonConverterFactory;

public class MainActivity extends AppCompatActivity {
    EditText txtName,txtPrice,txtDes,txtPid;
    Button btnInsert, btnGet,btnUpdate,btnDelete;
    TextView tvResult;
    /*
    * Bài 3: Retrofit
- Là 1 thư viện cho phép Android kết nối với Server và lấy dữ liệu từ server
- Rest API
- Các bước thực hiện:
1. Xem cấu trúc của API (~ json)
	*Post
	*có 3 tham số truyền: name, price, description
	*Tên bảng dữ liệu: products
2. Thiết kế model tương ứng với bảng dữ liệu:(tên model nên trùng tên bảng)
3. Thiết kế list dữ liệu trả về:
	* tên tập dữ liệu phải trùng với tên bảng (products)
	* mesage -> lấy thông báo
	* result -> lấy kết quả
4. Thiết kế interface cho phép tương tác với API (GET, POST)
5. Gọi thư viện Retrofit xử lý
------------
GetData
1. Cau truc JSON
	products(pid,name,price)
2. Thiet ke model
	products(pid,name,price)
3. Thiet ke list du lieu tra ve tu server
	tên biến của tập dữ liệu phải là products
4. Dinh nghia interface lay du lieu
5. Goi Retrofit*/

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        txtName = findViewById(R.id.txtName);
        txtDes = findViewById(R.id.txtDes);
        txtPrice = findViewById(R.id.txPrice);
        btnGet = findViewById(R.id.btnGet);
        tvResult = findViewById(R.id.tvRessult);
        txtPid = findViewById(R.id.txtPid);
        btnInsert = findViewById(R.id.btnInsert);
        btnUpdate = findViewById(R.id.btnUpdate);
        btnDelete = findViewById(R.id.btnDelete);
        btnInsert.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                insertData();
            }
        });
        btnGet.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                getData();
            }
        });
        btnUpdate.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                updateData();
            }
        });
        btnDelete.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                DeleteFunction deleteFunction= new DeleteFunction();
                deleteFunction.deleteFn(tvResult,txtPid.getText().toString());
            }
        });
    }
    ///--------------------start update
    public void updateData()
    {
        PrdUpdate p = new PrdUpdate();
        p.setPid(txtPid.getText().toString());
        p.setName(txtName.getText().toString());
        p.setPrice(txtPrice.getText().toString());
        p.setDescription(txtDes.getText().toString());
        FunctionUpdate f = new FunctionUpdate();
        f.updateFn(tvResult,p);

    }
    ///--------------------end update
    ////----start delete----
    ////end delete
    String strkq="";
    List<Products> ls;
    public void getData()
    {
        //1.Tao doi tuong retro
        Retrofit retrofit = new Retrofit.Builder()
                .baseUrl("https://batdongsanabc.000webhostapp.com/mob403lab4/")
                .addConverterFactory(GsonConverterFactory.create())
                .build();
        //2. lay request
        InterfaceGetData interfaceGetData
                =retrofit.create(InterfaceGetData.class);
        Call<SrvResponseProducts> call = interfaceGetData.GetJSON();
        //3. thuc thi request
        call.enqueue(new Callback<SrvResponseProducts>() {
            @Override
            public void onResponse(Call<SrvResponseProducts> call, Response<SrvResponseProducts> response) {
                SrvResponseProducts srvResponseProducts = response.body();//tra ve ket qua
                //chuyen ket qua sang chuoi
                ls = new ArrayList<>(Arrays.asList(srvResponseProducts.getProducts()));
                for(Products p: ls)
                {
                    strkq += "Name: "+p.getName()+"; price: "+p.getPrice()+"\n\n";
                }
                tvResult.setText(strkq);
            }

            @Override
            public void onFailure(Call<SrvResponseProducts> call, Throwable t) {
                tvResult.setText(t.getMessage());
            }
        });
    }
    public void insertData()
    {
        //tao doi tuong chua du lieu
        Prd prd = new Prd();
        //dua du lieu nhap tren form vao doi tuong
        prd.setName(txtName.getText().toString());
        prd.setPrice(txtPrice.getText().toString());
        prd.setDescription(txtDes.getText().toString());
        //1.Tao doi tuong Retrofit
        Retrofit retrofit = new Retrofit.Builder()
                .baseUrl("https://batdongsanabc.000webhostapp.com/mob403lab5/")
                .addConverterFactory(GsonConverterFactory.create())
                .build();
        //2.goi interface
        InterInsertPrd interInsertPrd=retrofit.create(InterInsertPrd.class);
        //3. chuan bi ham
        Call<SvrResponsePrd> call
                =interInsertPrd.insertPrd(prd.getName(),prd.getPrice(),prd.getDescription());
        //4. thuc thi ham
        call.enqueue(new Callback<SvrResponsePrd>() {
            @Override
            public void onResponse(Call<SvrResponsePrd> call, Response<SvrResponsePrd> response) {
                //tra ve ket qua neu thanh cong
                SvrResponsePrd svrResponsePrd = response.body();
                tvResult.setText(svrResponsePrd.getMessage());
            }

            @Override
            public void onFailure(Call<SvrResponsePrd> call, Throwable t) {
                tvResult.setText(t.getMessage());
            }
        });


    }
}
