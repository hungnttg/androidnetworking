package com.example.retro1.DeleteData;

public class PrdDelete {
    private String pid;

    public String getPid() {
        return pid;
    }

    public void setPid(String pid) {
        this.pid = pid;
    }
}
