package com.example.retro1.UpdateData;

public class ConstUpdate {
    public static final String BASE_URL="https://batdongsanabc.000webhostapp.com/mob403lab5/";
    public static final String OPERATION_UPDATE="update";
}
