package com.example.retro1.DeleteData;

public class ResponseDelete {//get
    private PrdDelete products;
    private String message;
    private String result;

    public PrdDelete getProducts() {
        return products;
    }

    public String getMessage() {
        return message;
    }

    public String getResult() {
        return result;
    }
}
