package com.example.lab2.L22;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import com.example.lab2.R;

public class L22MainActivity extends AppCompatActivity
        implements View.OnClickListener {
    TextView tvkq;
    String link;
    EditText txtName,txtScore;
    Button btnLoad;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_l22_main);

        tvkq = findViewById(R.id.l22tvKQ);
        link = "http://192.168.40.100/API-L2-NKW/std_GET.php";
        txtName = findViewById(R.id.l22edName);
        txtScore = findViewById(R.id.l22edScore);
        btnLoad = findViewById(R.id.l22Btn);

        btnLoad.setOnClickListener(this);
    }

    @Override
    public void onClick(View v) {
L22AsyncTaskGet l22AsyncTaskGet = new L22AsyncTaskGet(this,
        link,txtName.getText().toString(),txtScore.getText().toString(),tvkq);
l22AsyncTaskGet.execute();
    }
}
