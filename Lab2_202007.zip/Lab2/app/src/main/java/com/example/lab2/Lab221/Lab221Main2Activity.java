package com.example.lab2.Lab221;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import com.example.lab2.R;

public class Lab221Main2Activity extends AppCompatActivity implements View.OnClickListener {

    EditText txtName, txtScore;
    Button btn;
    TextView tvResult;
    String link = "https://batdongsanabc.000webhostapp.com/lab14/sinhvien_GET.php";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_lab221_main2);

        txtName = findViewById(R.id.l221Name);
        txtScore = findViewById(R.id.l221Score);
        btn = findViewById(R.id.l221btn);
        tvResult = findViewById(R.id.l221KetQua);
        btn.setOnClickListener(this);
    }

    @Override
    public void onClick(View v) {
        String n=txtName.getText().toString();
        String s = txtScore.getText().toString();
        link += "?name="+n+"&score="+s;
        Lab221AsyncTask_GET l = new Lab221AsyncTask_GET(this,link,
                n,s,tvResult);
        l.execute();

    }
}
