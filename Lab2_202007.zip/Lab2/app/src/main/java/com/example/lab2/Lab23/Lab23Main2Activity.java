package com.example.lab2.Lab23;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import com.example.lab2.R;

public class Lab23Main2Activity extends AppCompatActivity implements View.OnClickListener {
    TextView tvRs;
    Button btn;
    EditText txtDai, txtRong;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_lab23_main2);

        tvRs = findViewById(R.id.l23kq);
        txtDai = findViewById(R.id.l23dai);
        txtRong = findViewById(R.id.l23Rong);
        btn = findViewById(R.id.l23btn);

        btn.setOnClickListener(this);
    }

    @Override
    public void onClick(View v) {
        String link = "http://192.168.40.100/API-L2-NKW/dientich_POST.php";
        AsyncTask_POST apost = new AsyncTask_POST(this,txtDai.getText().toString(),
                txtRong.getText().toString(),link,tvRs);
        apost.execute();
    }
}
