package com.example.lab2;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

public class Lab24Activity extends AppCompatActivity implements View.OnClickListener {

    String link = "http://192.168.1.101/API-L2-NKW/giaiphuongtrinh_POST.php";
    //String link = "https://batdongsanabc.000webhostapp.com/lab14/giaiphuongtrinh_POST.php";
    EditText txtA, txtB, txtC;
    TextView tvKQ;
    Button btnTinh;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_lab24);

        btnTinh = findViewById(R.id.l24Btn);
        txtA = findViewById(R.id.l24txtA);
        txtB = findViewById(R.id.l24txtB);
        txtC = findViewById(R.id.l24txtC);
        tvKQ = findViewById(R.id.l24KqtQua);
        btnTinh.setOnClickListener(this);
    }

    @Override
    public void onClick(View v) {
        String a = txtA.getText().toString();
        String b = txtB.getText().toString();
        String c = txtC.getText().toString();
        Lab24AsyncTask_POST l24 = new Lab24AsyncTask_POST(this,link,a,b,c,tvKQ);
        l24.execute();
    }
}
