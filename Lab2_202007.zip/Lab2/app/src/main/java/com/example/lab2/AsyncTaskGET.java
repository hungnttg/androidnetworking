package com.example.lab2;

import android.app.ProgressDialog;
import android.content.Context;
import android.os.AsyncTask;
import android.widget.TextView;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;

public class AsyncTaskGET extends AsyncTask<String,Void,String> {
    private String name;
    private String score;
    private TextView tvRs;
    Context context;
    ProgressDialog progressDialog;
    String link;
    String kq;

    public AsyncTaskGET(Context context,String name,
                        String score,TextView tvRs,String link)
    {
        this.context = context;
        this.name = name;
        this.score = score;
        this.tvRs = tvRs;
        this.link = link;
    }

    @Override
    protected void onPreExecute() {
        super.onPreExecute();
    }

    @Override
    protected String doInBackground(String... strings) {
        link +="?name="+this.name+"&score="+this.score;
        URL url;
        try {
             url = new URL(link);
            HttpURLConnection urlConnection =
                    (HttpURLConnection)url.openConnection();
            BufferedReader br = new BufferedReader(new
                    InputStreamReader(urlConnection.getInputStream()));
            String line="";
            StringBuffer sb = new StringBuffer();
            while ((line=br.readLine())!=null)
            {
                sb.append(line);
            }
            kq = sb.toString();
            urlConnection.disconnect();
        } catch (Exception e) {
            e.printStackTrace();
        }
        return kq;
    }

    @Override
    protected void onProgressUpdate(Void... values) {
        super.onProgressUpdate(values);
        progressDialog.show();
    }

    @Override
    protected void onPostExecute(String s) {
        super.onPostExecute(s);
//        if(progressDialog.isShowing())
//        {
//            progressDialog.dismiss();
//        }
        tvRs.setText("Name & score "+kq);
    }
}
