package com.example.lab2;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity implements View.OnClickListener {

    Button button;
    TextView textView;
    EditText txtName,txtScore;
    AsyncTaskGET asyncTaskGET;
    String link="http://10.22.216.65/API-L2-NKW/student_GET.php";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        button = findViewById(R.id.btnGet);
        textView = findViewById(R.id.tvResult);
        txtName = findViewById(R.id.edName);
        txtScore = findViewById(R.id.edScore);

        button.setOnClickListener(this);


    }

    @Override
    public void onClick(View v) {
        asyncTaskGET = new AsyncTaskGET(this,txtName.getText().toString(),
                txtScore.getText().toString(),textView,link);
        asyncTaskGET.execute();
    }
}
