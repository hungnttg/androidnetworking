<?php
	if (!empty($_SERVER['HTTPS']) && ('on' == $_SERVER['HTTPS'])) {
		$uri = 'https://';
	} else {
		$uri = 'http://';
	}
	$uri .= $_SERVER['HTTP_HOST'].'API-L2-NKW/lab5/';
	echo $uri;
	if($uri=='http://192.168.20.101API-L2-NKW/lab5/')
	{
		$link = $uri.'?ts=getall';
		echo $link;
		if($link=='http://192.168.20.101API-L2-NKW/lab5/?ts=getall')
		{
			header('Location: '.'http://192.168.20.101/API-L2-NKW/lab5/get_all_product.php');
		}
		
	}
	
	exit;
?>
Something is wrong with the XAMPP installation :-(
